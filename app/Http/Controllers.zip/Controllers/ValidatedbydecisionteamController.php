<?php

namespace App\Http\Controllers;

use App\Models\validatedbydecisionteam;
use App\Http\Requests\StorevalidatedbydecisionteamRequest;
use App\Http\Requests\UpdatevalidatedbydecisionteamRequest;

class ValidatedbydecisionteamController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorevalidatedbydecisionteamRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorevalidatedbydecisionteamRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\validatedbydecisionteam  $validatedbydecisionteam
     * @return \Illuminate\Http\Response
     */
    public function show(validatedbydecisionteam $validatedbydecisionteam)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\validatedbydecisionteam  $validatedbydecisionteam
     * @return \Illuminate\Http\Response
     */
    public function edit(validatedbydecisionteam $validatedbydecisionteam)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatevalidatedbydecisionteamRequest  $request
     * @param  \App\Models\validatedbydecisionteam  $validatedbydecisionteam
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatevalidatedbydecisionteamRequest $request, validatedbydecisionteam $validatedbydecisionteam)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\validatedbydecisionteam  $validatedbydecisionteam
     * @return \Illuminate\Http\Response
     */
    public function destroy(validatedbydecisionteam $validatedbydecisionteam)
    {
        //
    }
}
