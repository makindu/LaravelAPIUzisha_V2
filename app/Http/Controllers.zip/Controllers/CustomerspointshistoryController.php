<?php

namespace App\Http\Controllers;

use App\Models\customerspointshistory;
use App\Http\Controllers\Controller;
use App\Http\Requests\StorecustomerspointshistoryRequest;
use App\Http\Requests\UpdatecustomerspointshistoryRequest;

class CustomerspointshistoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorecustomerspointshistoryRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorecustomerspointshistoryRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\customerspointshistory  $customerspointshistory
     * @return \Illuminate\Http\Response
     */
    public function show(customerspointshistory $customerspointshistory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\customerspointshistory  $customerspointshistory
     * @return \Illuminate\Http\Response
     */
    public function edit(customerspointshistory $customerspointshistory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatecustomerspointshistoryRequest  $request
     * @param  \App\Models\customerspointshistory  $customerspointshistory
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatecustomerspointshistoryRequest $request, customerspointshistory $customerspointshistory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\customerspointshistory  $customerspointshistory
     * @return \Illuminate\Http\Response
     */
    public function destroy(customerspointshistory $customerspointshistory)
    {
        //
    }
}
