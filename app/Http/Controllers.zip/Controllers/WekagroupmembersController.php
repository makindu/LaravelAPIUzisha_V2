<?php

namespace App\Http\Controllers;

use App\Models\wekagroupmembers;
use App\Http\Controllers\Controller;
use App\Http\Requests\StorewekagroupmembersRequest;
use App\Http\Requests\UpdatewekagroupmembersRequest;

class WekagroupmembersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StorewekagroupmembersRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StorewekagroupmembersRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\wekagroupmembers  $wekagroupmembers
     * @return \Illuminate\Http\Response
     */
    public function show(wekagroupmembers $wekagroupmembers)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\wekagroupmembers  $wekagroupmembers
     * @return \Illuminate\Http\Response
     */
    public function edit(wekagroupmembers $wekagroupmembers)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatewekagroupmembersRequest  $request
     * @param  \App\Models\wekagroupmembers  $wekagroupmembers
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatewekagroupmembersRequest $request, wekagroupmembers $wekagroupmembers)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\wekagroupmembers  $wekagroupmembers
     * @return \Illuminate\Http\Response
     */
    public function destroy(wekagroupmembers $wekagroupmembers)
    {
        //
    }
}
