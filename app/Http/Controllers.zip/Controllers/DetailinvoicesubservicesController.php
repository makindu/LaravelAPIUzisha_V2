<?php

namespace App\Http\Controllers;

use App\Models\detailinvoicesubservices;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoredetailinvoicesubservicesRequest;
use App\Http\Requests\UpdatedetailinvoicesubservicesRequest;

class DetailinvoicesubservicesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoredetailinvoicesubservicesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoredetailinvoicesubservicesRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\detailinvoicesubservices  $detailinvoicesubservices
     * @return \Illuminate\Http\Response
     */
    public function show(detailinvoicesubservices $detailinvoicesubservices)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\detailinvoicesubservices  $detailinvoicesubservices
     * @return \Illuminate\Http\Response
     */
    public function edit(detailinvoicesubservices $detailinvoicesubservices)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatedetailinvoicesubservicesRequest  $request
     * @param  \App\Models\detailinvoicesubservices  $detailinvoicesubservices
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatedetailinvoicesubservicesRequest $request, detailinvoicesubservices $detailinvoicesubservices)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\detailinvoicesubservices  $detailinvoicesubservices
     * @return \Illuminate\Http\Response
     */
    public function destroy(detailinvoicesubservices $detailinvoicesubservices)
    {
        //
    }
}
