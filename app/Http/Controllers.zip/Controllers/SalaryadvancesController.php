<?php

namespace App\Http\Controllers;

use App\Models\salaryadvances;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoresalaryadvancesRequest;
use App\Http\Requests\UpdatesalaryadvancesRequest;

class SalaryadvancesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoresalaryadvancesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoresalaryadvancesRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\salaryadvances  $salaryadvances
     * @return \Illuminate\Http\Response
     */
    public function show(salaryadvances $salaryadvances)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\salaryadvances  $salaryadvances
     * @return \Illuminate\Http\Response
     */
    public function edit(salaryadvances $salaryadvances)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdatesalaryadvancesRequest  $request
     * @param  \App\Models\salaryadvances  $salaryadvances
     * @return \Illuminate\Http\Response
     */
    public function update(UpdatesalaryadvancesRequest $request, salaryadvances $salaryadvances)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\salaryadvances  $salaryadvances
     * @return \Illuminate\Http\Response
     */
    public function destroy(salaryadvances $salaryadvances)
    {
        //
    }
}
